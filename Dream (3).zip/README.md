!! == Je tiens à souligner que je ne suis en aucun cas responsable des actions qui peuvent être effectuer avec mon outils == !!

# Comment le faire marcher ?
git clone https://github.com/user/repository
cd Dream
pip install pycryptodome
python dream.py

# Pourquoi je ne trouve rien ?
1 - Car l'utilisateur ne se trouve pas dans vos database // ou vous n'avez pas ajouter de database

# L'outils est illégal ?
Non il est 100% legal en temps normal appart si vous ajouté des database, ou que vous divulgé les information que vous trouver dans vos database

